"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ExternalLink, Trash2 } from "lucide-react"

interface SunglassesItem {
  id: number
  name: string
  stock: number
  price: number
  totalWholesalePrice: number
  image: string
  buyLink: string
}

export default function Inventory() {
  const [inventory, setInventory] = useState<SunglassesItem[]>([])
  const [editingId, setEditingId] = useState<number | null>(null)
  const [newItem, setNewItem] = useState<Partial<SunglassesItem>>({})
  const router = useRouter()

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn") === "true"
    if (!isLoggedIn) {
      router.push("/login")
      return
    }

    const savedInventory = JSON.parse(localStorage.getItem("inventory") || "[]")
    setInventory(savedInventory)
  }, [router])

  const handleEdit = (id: number) => {
    setEditingId(id)
  }

  const handleSave = (id: number) => {
    setEditingId(null)
    localStorage.setItem("inventory", JSON.stringify(inventory))
  }

  const handleChange = (id: number, field: keyof SunglassesItem, value: string) => {
    setInventory(
      inventory.map((item) =>
        item.id === id
          ? { ...item, [field]: field === "name" || field === "image" || field === "buyLink" ? value : Number(value) }
          : item,
      ),
    )
  }

  const handleAddItem = () => {
    if (
      newItem.name &&
      newItem.stock &&
      newItem.price &&
      newItem.totalWholesalePrice &&
      newItem.image &&
      newItem.buyLink
    ) {
      const newItemWithId = { ...newItem, id: inventory.length + 1 } as SunglassesItem
      const updatedInventory = [...inventory, newItemWithId]
      setInventory(updatedInventory)
      localStorage.setItem("inventory", JSON.stringify(updatedInventory))
      setNewItem({})
    } else {
      alert("Please fill all fields!")
    }
  }

  const handleDeleteItem = (id: number) => {
    const updatedInventory = inventory.filter((item) => item.id !== id)
    setInventory(updatedInventory)
    localStorage.setItem("inventory", JSON.stringify(updatedInventory))
  }

  const calculateWholesalePrice = (item: SunglassesItem) => {
    return item.stock > 0 ? item.totalWholesalePrice / item.stock : 0
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Inventory Management</h1>
        <Link href="/">
          <Button variant="outline">Go Back Home</Button>
        </Link>
      </div>

      <div className="mb-8 p-4 border rounded-lg">
        <h2 className="text-xl font-semibold mb-4">Add New Item</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <Label htmlFor="new-name">Name</Label>
            <Input
              id="new-name"
              value={newItem.name || ""}
              onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
            />
          </div>
          <div>
            <Label htmlFor="new-stock">Stock</Label>
            <Input
              id="new-stock"
              type="number"
              value={newItem.stock || ""}
              onChange={(e) => setNewItem({ ...newItem, stock: Number(e.target.value) })}
            />
          </div>
          <div>
            <Label htmlFor="new-price">Retail Price</Label>
            <Input
              id="new-price"
              type="number"
              value={newItem.price || ""}
              onChange={(e) => setNewItem({ ...newItem, price: Number(e.target.value) })}
            />
          </div>
          <div>
            <Label htmlFor="new-wholesale">Total Wholesale Price</Label>
            <Input
              id="new-wholesale"
              type="number"
              value={newItem.totalWholesalePrice || ""}
              onChange={(e) => setNewItem({ ...newItem, totalWholesalePrice: Number(e.target.value) })}
            />
          </div>
          <div>
            <Label htmlFor="new-image">Image URL</Label>
            <Input
              id="new-image"
              value={newItem.image || ""}
              onChange={(e) => setNewItem({ ...newItem, image: e.target.value })}
            />
          </div>
          <div>
            <Label htmlFor="new-buylink">Buy Link</Label>
            <Input
              id="new-buylink"
              value={newItem.buyLink || ""}
              onChange={(e) => setNewItem({ ...newItem, buyLink: e.target.value })}
            />
          </div>
        </div>
        <Button className="mt-4" onClick={handleAddItem}>
          Add Item
        </Button>
      </div>

      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Image</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Stock</TableHead>
              <TableHead>Retail Price</TableHead>
              <TableHead>Total Wholesale Price</TableHead>
              <TableHead>Per-Unit Wholesale Price</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Buy Link</TableHead>
              <TableHead>Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {inventory.map((item) => (
              <TableRow key={item.id}>
                <TableCell>{item.id}</TableCell>
                <TableCell>
                  {editingId === item.id ? (
                    <Input value={item.image} onChange={(e) => handleChange(item.id, "image", e.target.value)} />
                  ) : (
                    <Image
                      src={item.image || "/placeholder.svg"}
                      alt={item.name}
                      width={100}
                      height={50}
                      className="object-cover rounded-md"
                    />
                  )}
                </TableCell>
                <TableCell>
                  {editingId === item.id ? (
                    <Input value={item.name} onChange={(e) => handleChange(item.id, "name", e.target.value)} />
                  ) : (
                    item.name
                  )}
                </TableCell>
                <TableCell>
                  {editingId === item.id ? (
                    <Input
                      type="number"
                      value={item.stock}
                      onChange={(e) => handleChange(item.id, "stock", e.target.value)}
                    />
                  ) : (
                    item.stock
                  )}
                </TableCell>
                <TableCell>
                  {editingId === item.id ? (
                    <Input
                      type="number"
                      value={item.price}
                      onChange={(e) => handleChange(item.id, "price", e.target.value)}
                    />
                  ) : (
                    `$${item.price.toFixed(2)}`
                  )}
                </TableCell>
                <TableCell>
                  {editingId === item.id ? (
                    <Input
                      type="number"
                      value={item.totalWholesalePrice}
                      onChange={(e) => handleChange(item.id, "totalWholesalePrice", e.target.value)}
                    />
                  ) : (
                    `$${item.totalWholesalePrice.toFixed(2)}`
                  )}
                </TableCell>
                <TableCell>${calculateWholesalePrice(item).toFixed(2)}</TableCell>
                <TableCell>
                  <Badge variant={item.stock < 10 ? "destructive" : "secondary"}>
                    {item.stock < 10 ? "Low Stock" : "In Stock"}
                  </Badge>
                </TableCell>
                <TableCell>
                  {editingId === item.id ? (
                    <Input value={item.buyLink} onChange={(e) => handleChange(item.id, "buyLink", e.target.value)} />
                  ) : (
                    <a href={item.buyLink} target="_blank" rel="noopener noreferrer">
                      <Button variant="outline" size="sm">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Buy
                      </Button>
                    </a>
                  )}
                </TableCell>
                <TableCell>
                  <div className="flex gap-2">
                    {editingId === item.id ? (
                      <Button onClick={() => handleSave(item.id)}>Save</Button>
                    ) : (
                      <Button variant="outline" onClick={() => handleEdit(item.id)}>
                        Edit
                      </Button>
                    )}
                    <Button variant="destructive" onClick={() => handleDeleteItem(item.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}


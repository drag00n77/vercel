"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface Order {
  id: number
  productId: number
  productName: string
  quantity: number
  totalCost: number
  status: "Pending" | "Shipped" | "Delivered" | "Cancelled"
  date: string
  timestamp: string
}

interface InventoryItem {
  id: number
  name: string
  stock: number
  price: number
  totalWholesalePrice: number // Added totalWholesalePrice
  image: string
  buyLink: string
}

export default function Orders() {
  const [orders, setOrders] = useState<Order[]>([])
  const [inventory, setInventory] = useState<InventoryItem[]>([])
  const [newOrder, setNewOrder] = useState<Partial<Order>>({})
  const router = useRouter()

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn") === "true"
    if (!isLoggedIn) {
      router.push("/login")
      return
    }

    const savedOrders = JSON.parse(localStorage.getItem("orders") || "[]")
    setOrders(savedOrders)

    const savedInventory = JSON.parse(localStorage.getItem("inventory") || "[]")
    setInventory(savedInventory)
  }, [router])

  const handleAddOrder = () => {
    if (newOrder.productId && newOrder.quantity) {
      const product = inventory.find((item) => item.id === newOrder.productId)
      if (product) {
        const order: Order = {
          id: orders.length + 1,
          productId: newOrder.productId,
          productName: product.name,
          quantity: newOrder.quantity,
          totalCost: (product.totalWholesalePrice / product.stock) * newOrder.quantity, // Updated totalCost calculation
          status: "Pending",
          date: new Date().toISOString().split("T")[0],
          timestamp: new Date().toISOString(),
        }
        const updatedOrders = [...orders, order]
        setOrders(updatedOrders)
        localStorage.setItem("orders", JSON.stringify(updatedOrders))
        setNewOrder({})
      } else {
        alert("Product not found!")
      }
    } else {
      alert("Please fill all fields!")
    }
  }

  const handleUpdateStatus = (id: number, newStatus: "Pending" | "Shipped" | "Delivered" | "Cancelled") => {
    const updatedOrders = orders.map((order) => {
      if (order.id === id) {
        if (newStatus === "Delivered" && order.status !== "Delivered") {
          // Increase stock when order is delivered
          const updatedInventory = inventory.map((item) =>
            item.id === order.productId ? { ...item, stock: item.stock + order.quantity } : item,
          )
          setInventory(updatedInventory)
          localStorage.setItem("inventory", JSON.stringify(updatedInventory))
        } else if (order.status === "Delivered" && newStatus === "Cancelled") {
          // Decrease stock if cancelling a delivered order
          const updatedInventory = inventory.map((item) =>
            item.id === order.productId ? { ...item, stock: item.stock - order.quantity } : item,
          )
          setInventory(updatedInventory)
          localStorage.setItem("inventory", JSON.stringify(updatedInventory))
        }
        return { ...order, status: newStatus }
      }
      return order
    })
    setOrders(updatedOrders)
    localStorage.setItem("orders", JSON.stringify(updatedOrders))
  }

  const handleCancelOrder = (id: number) => {
    handleUpdateStatus(id, "Cancelled")
  }

  const totalOrders = orders.length
  const totalCost = orders.reduce((sum, order) => sum + order.totalCost, 0)

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Order Management</h1>
        <Link href="/">
          <Button variant="outline">Go Back Home</Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Total Orders</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{totalOrders}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Total Cost</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">${totalCost.toFixed(2)}</p>
          </CardContent>
        </Card>
      </div>

      <div className="mb-6 flex gap-4">
        <Input
          type="number"
          placeholder="Product ID"
          value={newOrder.productId || ""}
          onChange={(e) => setNewOrder({ ...newOrder, productId: Number(e.target.value) })}
        />
        <Input
          type="number"
          placeholder="Quantity"
          value={newOrder.quantity || ""}
          onChange={(e) => setNewOrder({ ...newOrder, quantity: Number(e.target.value) })}
        />
        <Button onClick={handleAddOrder}>Place Order</Button>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>ID</TableHead>
            <TableHead>Product</TableHead>
            <TableHead>Quantity</TableHead>
            <TableHead>Total Cost</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Date</TableHead>
            <TableHead>Time</TableHead>
            <TableHead>Action</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {orders.map((order) => (
            <TableRow key={order.id}>
              <TableCell>{order.id}</TableCell>
              <TableCell>{order.productName}</TableCell>
              <TableCell>{order.quantity}</TableCell>
              <TableCell>${order.totalCost.toFixed(2)}</TableCell>
              <TableCell>{order.status}</TableCell>
              <TableCell>{order.date}</TableCell>
              <TableCell>{new Date(order.timestamp).toLocaleTimeString()}</TableCell>
              <TableCell>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => handleUpdateStatus(order.id, "Shipped")}
                    disabled={order.status !== "Pending"}
                  >
                    Ship
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => handleUpdateStatus(order.id, "Delivered")}
                    disabled={order.status !== "Shipped"}
                  >
                    Deliver
                  </Button>
                  <Button
                    variant="destructive"
                    onClick={() => handleCancelOrder(order.id)}
                    disabled={order.status === "Cancelled"}
                  >
                    Cancel
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}


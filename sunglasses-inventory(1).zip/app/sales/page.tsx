"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { ChevronLeft, ChevronRight } from "lucide-react"

interface SaleItem {
  id: number
  productId: number
  productName: string
  quantity: number
  salePrice: number
  wholesalePrice: number
  date: string
}

interface SalesAnalysis {
  productId: number
  productName: string
  totalQuantity: number
  totalRevenue: number
  totalProfit: number
  percentageOfSales: number
  percentageOfProfit: number
}

interface InventoryItem {
  id: number
  name: string
  stock: number
  price: number
  wholesalePrice: number
  image: string
}

export default function Sales() {
  const [sales, setSales] = useState<SaleItem[]>([])
  const [inventory, setInventory] = useState<InventoryItem[]>([])
  const [newSale, setNewSale] = useState<Partial<SaleItem>>({})
  const [salesAnalysis, setSalesAnalysis] = useState<SalesAnalysis[]>([])
  const [currentPage, setCurrentPage] = useState(1)
  const [selectedProduct, setSelectedProduct] = useState<InventoryItem | null>(null)
  const itemsPerPage = 10
  const router = useRouter()

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn") === "true"
    if (!isLoggedIn) {
      router.push("/login")
      return
    }

    const savedSales = JSON.parse(localStorage.getItem("sales") || "[]")
    setSales(savedSales)

    const savedInventory = JSON.parse(localStorage.getItem("inventory") || "[]")
    setInventory(savedInventory)

    analyzeSales(savedSales)
  }, [router])

  const analyzeSales = (salesData: SaleItem[]) => {
    const analysis = salesData.reduce((acc: Record<number, SalesAnalysis>, sale) => {
      if (!acc[sale.productId]) {
        acc[sale.productId] = {
          productId: sale.productId,
          productName: sale.productName,
          totalQuantity: 0,
          totalRevenue: 0,
          totalProfit: 0,
          percentageOfSales: 0,
          percentageOfProfit: 0,
        }
      }
      acc[sale.productId].totalQuantity += sale.quantity
      acc[sale.productId].totalRevenue += sale.quantity * sale.salePrice
      acc[sale.productId].totalProfit += sale.quantity * (sale.salePrice - sale.wholesalePrice)
      return acc
    }, {})

    const totalRevenue = Object.values(analysis).reduce((sum, item) => sum + item.totalRevenue, 0)
    const totalProfit = Object.values(analysis).reduce((sum, item) => sum + item.totalProfit, 0)
    const analysisArray = Object.values(analysis).map((item) => ({
      ...item,
      percentageOfSales: (item.totalRevenue / totalRevenue) * 100,
      percentageOfProfit: (item.totalProfit / totalProfit) * 100,
    }))

    setSalesAnalysis(analysisArray.sort((a, b) => b.totalRevenue - a.totalRevenue))
  }

  const handleProductIdChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const productId = Number(e.target.value)
    setNewSale({ ...newSale, productId })
    const product = inventory.find((item) => item.id === productId)
    setSelectedProduct(product || null)
  }

  const handleAddSale = () => {
    if (newSale.productId && newSale.quantity && newSale.salePrice && selectedProduct) {
      if (selectedProduct.stock >= newSale.quantity) {
        const sale: SaleItem = {
          id: sales.length + 1,
          productId: newSale.productId,
          productName: selectedProduct.name,
          quantity: newSale.quantity,
          salePrice: newSale.salePrice,
          wholesalePrice: selectedProduct.wholesalePrice,
          date: new Date().toISOString().split("T")[0],
        }
        const updatedSales = [...sales, sale]
        setSales(updatedSales)
        localStorage.setItem("sales", JSON.stringify(updatedSales))

        // Update inventory
        const updatedInventory = inventory.map((item) =>
          item.id === newSale.productId ? { ...item, stock: item.stock - newSale.quantity } : item,
        )
        setInventory(updatedInventory)
        localStorage.setItem("inventory", JSON.stringify(updatedInventory))

        analyzeSales(updatedSales)
        setNewSale({})
        setSelectedProduct(null)
      } else {
        alert("Not enough stock!")
      }
    } else {
      alert("Please fill all fields!")
    }
  }

  const handleCancelSale = (saleId: number) => {
    const saleToCancel = sales.find((sale) => sale.id === saleId)
    if (saleToCancel) {
      // Update inventory
      const updatedInventory = inventory.map((item) =>
        item.id === saleToCancel.productId ? { ...item, stock: item.stock + saleToCancel.quantity } : item,
      )
      setInventory(updatedInventory)
      localStorage.setItem("inventory", JSON.stringify(updatedInventory))

      // Remove sale
      const updatedSales = sales.filter((sale) => sale.id !== saleId)
      setSales(updatedSales)
      localStorage.setItem("sales", JSON.stringify(updatedSales))

      analyzeSales(updatedSales)
    }
  }

  const totalRevenue = sales.reduce((sum, sale) => sum + sale.quantity * sale.salePrice, 0)
  const totalProfit = sales.reduce((sum, sale) => sum + sale.quantity * (sale.salePrice - sale.wholesalePrice), 0)
  const totalItems = sales.reduce((sum, sale) => sum + sale.quantity, 0)

  const pageCount = Math.ceil(sales.length / itemsPerPage)
  const paginatedSales = sales.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Sales Management</h1>
        <Link href="/">
          <Button variant="outline">Go Back Home</Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Total Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">${totalRevenue.toFixed(2)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Total Profit</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">${totalProfit.toFixed(2)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Total Items Sold</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{totalItems}</p>
          </CardContent>
        </Card>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Add New Sale</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 items-end">
            <div className="flex-1">
              <label htmlFor="productId" className="block text-sm font-medium text-gray-700 mb-1">
                Product ID
              </label>
              <Input
                id="productId"
                type="number"
                placeholder="Product ID"
                value={newSale.productId || ""}
                onChange={handleProductIdChange}
              />
            </div>
            {selectedProduct && (
              <div className="flex-1">
                <Image
                  src={selectedProduct.image || "/placeholder.svg"}
                  alt={selectedProduct.name}
                  width={100}
                  height={100}
                  className="object-cover rounded-md mb-2"
                />
                <p className="text-sm font-medium">{selectedProduct.name}</p>
              </div>
            )}
            <div className="flex-1">
              <label htmlFor="quantity" className="block text-sm font-medium text-gray-700 mb-1">
                Quantity
              </label>
              <Input
                id="quantity"
                type="number"
                placeholder="Quantity"
                value={newSale.quantity || ""}
                onChange={(e) => setNewSale({ ...newSale, quantity: Number(e.target.value) })}
              />
            </div>
            <div className="flex-1">
              <label htmlFor="salePrice" className="block text-sm font-medium text-gray-700 mb-1">
                Sale Price
              </label>
              <Input
                id="salePrice"
                type="number"
                placeholder="Sale Price"
                value={newSale.salePrice || ""}
                onChange={(e) => setNewSale({ ...newSale, salePrice: Number(e.target.value) })}
              />
            </div>
            <Button onClick={handleAddSale}>Add Sale</Button>
          </div>
        </CardContent>
      </Card>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Sales Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={salesAnalysis}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="productName" />
                <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                <Tooltip />
                <Legend />
                <Bar yAxisId="left" dataKey="totalRevenue" fill="#8884d8" name="Revenue ($)" />
                <Bar yAxisId="right" dataKey="totalProfit" fill="#82ca9d" name="Profit ($)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Product</TableHead>
            <TableHead>Quantity Sold</TableHead>
            <TableHead>Total Revenue</TableHead>
            <TableHead>Total Profit</TableHead>
            <TableHead>% of Sales</TableHead>
            <TableHead>% of Profit</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {salesAnalysis.map((item) => (
            <TableRow key={item.productId}>
              <TableCell>{item.productName}</TableCell>
              <TableCell>{item.totalQuantity}</TableCell>
              <TableCell>${item.totalRevenue.toFixed(2)}</TableCell>
              <TableCell>${item.totalProfit.toFixed(2)}</TableCell>
              <TableCell>{item.percentageOfSales.toFixed(2)}%</TableCell>
              <TableCell>{item.percentageOfProfit.toFixed(2)}%</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>

      <h2 className="text-2xl font-bold mt-8 mb-4">Recent Sales</h2>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>ID</TableHead>
            <TableHead>Product</TableHead>
            <TableHead>Quantity</TableHead>
            <TableHead>Sale Price</TableHead>
            <TableHead>Profit</TableHead>
            <TableHead>Date</TableHead>
            <TableHead>Action</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {paginatedSales.map((sale) => (
            <TableRow key={sale.id}>
              <TableCell>{sale.id}</TableCell>
              <TableCell>{sale.productName}</TableCell>
              <TableCell>{sale.quantity}</TableCell>
              <TableCell>${sale.salePrice.toFixed(2)}</TableCell>
              <TableCell>${((sale.salePrice - sale.wholesalePrice) * sale.quantity).toFixed(2)}</TableCell>
              <TableCell>{sale.date}</TableCell>
              <TableCell>
                <Button variant="destructive" onClick={() => handleCancelSale(sale.id)}>
                  Cancel Sale
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <div className="flex justify-between items-center mt-4">
        <Button onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))} disabled={currentPage === 1}>
          <ChevronLeft className="mr-2 h-4 w-4" /> Previous
        </Button>
        <span>
          Page {currentPage} of {pageCount}
        </span>
        <Button
          onClick={() => setCurrentPage((prev) => Math.min(prev + 1, pageCount))}
          disabled={currentPage === pageCount}
        >
          Next <ChevronRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}


"use client"

import Link from "next/link"
import { useEffect, useState } from "react"
import { usePathname, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"

const routes = ["/", "/inventory", "/sales", "/orders"]

export default function Header() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  useEffect(() => {
    setIsLoggedIn(localStorage.getItem("isLoggedIn") === "true")
  }, [])

  const pathname = usePathname()
  const router = useRouter()

  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn")
    router.push("/login")
  }

  const currentIndex = routes.indexOf(pathname)
  const canGoBack = currentIndex > 0
  const canGoForward = currentIndex < routes.length - 1

  const handleNavigation = (direction: "back" | "forward") => {
    const newIndex = direction === "back" ? currentIndex - 1 : currentIndex + 1
    if (newIndex >= 0 && newIndex < routes.length) {
      router.push(routes[newIndex])
    }
  }

  return (
    <header className="bg-white shadow">
      <nav className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/" className="text-xl font-bold mr-4">
            SunnySpecs Wholesale
          </Link>
          {isLoggedIn && (
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="icon" onClick={() => handleNavigation("back")} disabled={!canGoBack}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={() => handleNavigation("forward")}
                disabled={!canGoForward}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
        <div>
          {isLoggedIn ? (
            <>
              <Link href="/inventory" className="mr-4">
                <Button variant="outline">Inventory</Button>
              </Link>
              <Link href="/sales" className="mr-4">
                <Button variant="outline">Sales</Button>
              </Link>
              <Link href="/orders" className="mr-4">
                <Button variant="outline">Orders</Button>
              </Link>
              <Button onClick={handleLogout}>Logout</Button>
            </>
          ) : (
            <Link href="/login">
              <Button>Login</Button>
            </Link>
          )}
        </div>
      </nav>
    </header>
  )
}


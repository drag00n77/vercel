"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface InventoryStats {
  totalItems: number
  lowStockItems: number
  totalValue: number
}

export default function InventoryOverview() {
  const [stats, setStats] = useState<InventoryStats>({
    totalItems: 0,
    lowStockItems: 0,
    totalValue: 0,
  })

  useEffect(() => {
    const inventory = JSON.parse(localStorage.getItem("inventory") || "[]")
    const totalItems = inventory.reduce((sum: number, item: any) => sum + item.stock, 0)
    const lowStockItems = inventory.filter((item: any) => item.stock < 10).length
    const totalValue = inventory.reduce((sum: number, item: any) => sum + item.totalWholesalePrice, 0)

    setStats({
      totalItems,
      lowStockItems,
      totalValue,
    })
  }, [])

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Total Items in Stock</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-3xl font-bold">{stats.totalItems}</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Low Stock Items</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-3xl font-bold">{stats.lowStockItems}</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Total Inventory Value (Wholesale)</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-3xl font-bold">${stats.totalValue.toFixed(2)}</p>
        </CardContent>
      </Card>
    </div>
  )
}


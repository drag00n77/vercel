"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface Sunglasses {
  id: number
  name: string
  price: number
  image: string
  buyLink: string
  stock: number
}

export default function SunglassesList() {
  const [sunglasses, setSunglasses] = useState<Sunglasses[]>([])
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  useEffect(() => {
    // In a real application, this data would come from an API
    const mockData: Sunglasses[] = Array.from({ length: 20 }, (_, i) => ({
      id: i + 1,
      name: `Sunglasses Model ${i + 1}`,
      price: Math.floor(Math.random() * 100) + 1,
      image: `/placeholder.svg?height=200&width=200`,
      buyLink: "https://example.com",
      stock: Math.floor(Math.random() * 10),
    }))

    setSunglasses(mockData)

    const loggedIn = localStorage.getItem("isLoggedIn") === "true"
    setIsLoggedIn(loggedIn)

    if (loggedIn) {
      const savedInventory = JSON.parse(localStorage.getItem("inventory") || "{}")
      setSunglasses((prevState) =>
        prevState.map((item) => ({
          ...item,
          stock: savedInventory[item.id] || item.stock,
        })),
      )
    }
  }, [])

  const updateStock = (id: number, change: number) => {
    if (!isLoggedIn) return

    setSunglasses((prevState) =>
      prevState.map((item) => (item.id === id ? { ...item, stock: Math.max(0, item.stock + change) } : item)),
    )
  }

  useEffect(() => {
    if (isLoggedIn) {
      const inventory = sunglasses.reduce(
        (acc, item) => {
          acc[item.id] = item.stock
          return acc
        },
        {} as Record<number, number>,
      )
      localStorage.setItem("inventory", JSON.stringify(inventory))
    }
  }, [sunglasses, isLoggedIn])

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {sunglasses.map((item) => (
        <Card key={item.id} className="flex flex-col">
          <CardHeader>
            <CardTitle>{item.name}</CardTitle>
          </CardHeader>
          <CardContent className="flex-grow">
            <Image
              src={item.image || "/placeholder.svg"}
              alt={item.name}
              width={200}
              height={200}
              className="w-full h-auto mb-4"
            />
            <p className="text-2xl font-bold mb-2">${item.price}</p>
            {isLoggedIn && (
              <p className="mb-2">
                In stock: {item.stock}
                {item.stock < 5 && (
                  <Badge variant="destructive" className="ml-2">
                    Low Stock
                  </Badge>
                )}
              </p>
            )}
          </CardContent>
          <CardFooter className="flex justify-between">
            <a href={item.buyLink} target="_blank" rel="noopener noreferrer">
              <Button>Buy Now</Button>
            </a>
            {isLoggedIn && (
              <div>
                <Button variant="outline" onClick={() => updateStock(item.id, -1)} className="mr-2">
                  -
                </Button>
                <Button variant="outline" onClick={() => updateStock(item.id, 1)}>
                  +
                </Button>
              </div>
            )}
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}


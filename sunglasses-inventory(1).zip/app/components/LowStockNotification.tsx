"use client"

import { useState, useEffect } from "react"
import { X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface LowStockItem {
  id: number
  name: string
  stock: number
}

export default function LowStockNotification() {
  const [lowStockItems, setLowStockItems] = useState<LowStockItem[]>([])
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    const inventory = JSON.parse(localStorage.getItem("inventory") || "[]")
    const lowStock = inventory.filter((item: any) => item.stock < 10)
    setLowStockItems(lowStock)
  }, [])

  if (lowStockItems.length === 0 || !isVisible) {
    return null
  }

  return (
    <Card className="fixed bottom-4 right-4 w-80 z-50">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">Low Stock Alert</CardTitle>
        <Button variant="ghost" size="sm" onClick={() => setIsVisible(false)}>
          <X className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent>
        <ul className="mt-2">
          {lowStockItems.map((item) => (
            <li key={item.id} className="text-sm">
              {item.name}: {item.stock} left
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}


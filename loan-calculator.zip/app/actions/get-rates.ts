"use server"

import { FRED_SERIES_IDS, type FREDResponse, type LoanType } from "../lib/types"

async function fetchFREDRate(seriesId: string): Promise<string> {
  const url = `https://api.stlouisfed.org/fred/series/observations?series_id=${seriesId}&api_key=${process.env.FRED_API_KEY}&file_type=json&sort_order=desc&limit=1`

  const response = await fetch(url, { cache: "no-store" }) // Disable caching for on-demand updates

  if (!response.ok) {
    throw new Error(`FRED API error: ${response.statusText}`)
  }

  const data: FREDResponse = await response.json()

  if (!data.observations?.[0]?.value) {
    throw new Error("No rate data available")
  }

  return Number.parseFloat(data.observations[0].value).toFixed(2)
}

export async function getRates() {
  const rates: Partial<Record<LoanType, string>> = {}

  // Fetch all rates in parallel, excluding student loans
  const promises = Object.entries(FRED_SERIES_IDS)
    .filter(([type]) => type !== "student")
    .map(async ([type, seriesId]) => {
      try {
        const rate = await fetchFREDRate(seriesId)
        rates[type as LoanType] = rate
      } catch (error) {
        console.error(`Error fetching ${type} rate:`, error)
        // Do not add failed rates to the rates object
      }
    })

  await Promise.all(promises)

  return {
    ...rates, // Only include successfully fetched rates
    lastUpdated: new Date().toISOString(),
  }
}


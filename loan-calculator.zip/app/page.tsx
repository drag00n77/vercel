import { LoanCalculator } from "./components/loan-calculator"

export default function Home() {
  return (
    <main className="min-h-screen p-4 md:p-8 lg:p-12 bg-gray-50">
      <LoanCalculator />
    </main>
  )
}


"use client"

import { useState, useEffect, useCallback } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { RefreshCw } from "lucide-react"
import { getRates } from "../actions/get-rates"
import { type LoanType, loanTypeLabels } from "../lib/types"

interface Rates extends Partial<Record<LoanType, string>> {
  lastUpdated?: string
}

export function LoanCalculator() {
  const [loanType, setLoanType] = useState<LoanType>("personal")
  const [amount, setAmount] = useState(10000)
  const [years, setYears] = useState(5)
  const [months, setMonths] = useState(0)
  const [rates, setRates] = useState<Rates>({})
  const [monthlyPayment, setMonthlyPayment] = useState(0)
  const [isLoading, setIsLoading] = useState(true)
  const [isUpdating, setIsUpdating] = useState(false)

  const fetchRates = useCallback(async () => {
    try {
      setIsLoading(true)
      const newRates = await getRates()
      setRates(newRates)
    } catch (error) {
      console.error("Error fetching rates:", error)
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchRates()
  }, [fetchRates])

  const handleUpdateRates = async () => {
    setIsUpdating(true)
    await fetchRates()
    setIsUpdating(false)
  }

  useEffect(() => {
    if (rates[loanType]) {
      // Calculate monthly payment
      const rate = Number.parseFloat(rates[loanType]!) / 100 / 12 // Monthly interest rate
      const totalMonths = years * 12 + months // Total number of payments
      const monthlyPayment = (amount * rate * Math.pow(1 + rate, totalMonths)) / (Math.pow(1 + rate, totalMonths) - 1)

      setMonthlyPayment(isNaN(monthlyPayment) ? 0 : monthlyPayment)
    } else {
      setMonthlyPayment(0)
    }
  }, [amount, years, months, loanType, rates])

  const handleLoanTypeChange = (value: LoanType) => {
    setLoanType(value)
    // Reset loan term based on loan type
    switch (value) {
      case "mortgage30":
        setYears(30)
        setMonths(0)
        break
      case "mortgage15":
        setYears(15)
        setMonths(0)
        break
      case "mortgageARM":
        setYears(30)
        setMonths(0)
        break
      default:
        setYears(5)
        setMonths(0)
    }
  }

  const handleYearsChange = (value: number) => {
    const maxYears = getMaxYears()
    if (value > maxYears) {
      setYears(maxYears)
      setMonths(0)
    } else {
      setYears(value)
      // Adjust months if total term exceeds max years
      if (value * 12 + months > maxYears * 12) {
        setMonths(maxYears * 12 - value * 12)
      }
    }
  }

  const handleMonthsChange = (value: number) => {
    setMonths(value)
    const maxYears = getMaxYears()
    // Adjust years if total term exceeds max years
    if (years * 12 + value > maxYears * 12) {
      setYears(Math.floor((maxYears * 12 - value) / 12))
    }
  }

  const handleRateChange = (type: LoanType, value: string) => {
    setRates((prevRates) => ({
      ...prevRates,
      [type]: value,
    }))
  }

  const getMaxYears = () => {
    switch (loanType) {
      case "mortgage30":
      case "mortgageARM":
        return 30
      case "mortgage15":
        return 15
      default:
        return 10
    }
  }

  const availableLoanTypes = Object.keys(rates).filter((type) => type !== "lastUpdated") as LoanType[]

  return (
    <Card className="w-full max-w-lg mx-auto">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Loan Calculator</CardTitle>
          <Button onClick={handleUpdateRates} disabled={isUpdating}>
            <RefreshCw className={`mr-2 h-4 w-4 ${isUpdating ? "animate-spin" : ""}`} />
            Update Rates
          </Button>
        </div>
        <CardDescription>Calculate your monthly loan payments using current market rates</CardDescription>
        {rates.lastUpdated && (
          <div className="text-xs text-muted-foreground mt-1">
            Rates last updated: {new Date(rates.lastUpdated).toLocaleString()}
          </div>
        )}
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label>Loan Type</Label>
          <Select value={loanType} onValueChange={handleLoanTypeChange}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {availableLoanTypes.map((type) => (
                <SelectItem key={type} value={type}>
                  {loanTypeLabels[type]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {availableLoanTypes.map((type) => (
            <div key={type} className="space-y-2">
              <Label htmlFor={`${type}-rate`}>{loanTypeLabels[type]} Rate (%)</Label>
              <Input
                id={`${type}-rate`}
                type="number"
                value={rates[type] || ""}
                onChange={(e) => handleRateChange(type, e.target.value)}
                min={0}
                max={100}
                step={0.01}
              />
            </div>
          ))}
        </div>

        <div className="space-y-2">
          <Label>Loan Amount</Label>
          <div className="flex items-center space-x-4">
            <Input
              type="number"
              value={amount}
              onChange={(e) => setAmount(Number(e.target.value))}
              min={1000}
              max={1000000}
            />
            <Slider
              value={[amount]}
              onValueChange={(value) => setAmount(value[0])}
              min={1000}
              max={1000000}
              step={1000}
              className="w-full"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label>Loan Term</Label>
          <div className="flex items-center space-x-4">
            <div className="flex-1 space-y-2">
              <Label className="text-xs">Years</Label>
              <Input
                type="number"
                value={years}
                onChange={(e) => handleYearsChange(Number(e.target.value))}
                min={1}
                max={getMaxYears()}
              />
            </div>
            <div className="flex-1 space-y-2">
              <Label className="text-xs">Months</Label>
              <Input
                type="number"
                value={months}
                onChange={(e) => handleMonthsChange(Number(e.target.value))}
                min={0}
                max={11}
              />
            </div>
          </div>
          <Slider
            value={[years * 12 + months]}
            onValueChange={(value) => {
              const totalMonths = value[0]
              handleYearsChange(Math.floor(totalMonths / 12))
              setMonths(totalMonths % 12)
            }}
            min={1}
            max={getMaxYears() * 12}
            step={1}
            className="w-full"
          />
          <div className="text-xs text-muted-foreground">
            Total term: {years} years and {months} months (Max: {getMaxYears()} years)
          </div>
        </div>

        <div className="pt-6 border-t">
          <div className="text-2xl font-bold">Monthly Payment: ${monthlyPayment.toFixed(2)}</div>
          <div className="text-sm text-muted-foreground">
            Total Payment: ${(monthlyPayment * (years * 12 + months)).toFixed(2)}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}


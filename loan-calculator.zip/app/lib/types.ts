export type LoanType = "personal" | "auto" | "mortgage30" | "mortgage15" | "mortgageARM"

export interface FREDResponse {
  realtime_start: string
  realtime_end: string
  observation_start: string
  observation_end: string
  units: string
  output_type: number
  file_type: string
  order_by: string
  sort_order: string
  count: number
  offset: number
  limit: number
  observations: Array<{
    realtime_start: string
    realtime_end: string
    date: string
    value: string
  }>
}

export const FRED_SERIES_IDS: Record<LoanType, string> = {
  mortgage30: "MORTGAGE30US", // 30-Year Fixed Rate Mortgage Average
  mortgage15: "MORTGAGE15US", // 15-Year Fixed Rate Mortgage Average
  mortgageARM: "MORTGAGE5US", // 5/1-Year Adjustable Rate Mortgage Average
  personal: "TERMCBPER24NS", // Personal Loan Rate
  auto: "RIFLPBCIANM60NM", // Auto Loan Rate
}

export const loanTypeLabels: Record<LoanType, string> = {
  personal: "Personal Loan",
  auto: "Auto Loan",
  mortgage30: "30-Year Fixed Mortgage",
  mortgage15: "15-Year Fixed Mortgage",
  mortgageARM: "5/1 ARM Mortgage",
}

